import React from "react";
import { Navbar } from "../Navbar";
export const LayoutContent = (props) => {
    const {children,listMenu,logo} = props;
    return (
        <>
        <Navbar listMenu={listMenu} logo={logo} />
        <div className="container bg-gray-400 min-h-screen mx-auto">
        {children}
        </div>
        </>
    )
}