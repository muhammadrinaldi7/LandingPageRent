import {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import { faBars } from '@fortawesome/free-solid-svg-icons'
import { useState } from 'react';
export const Navbar = (props) => {
    const { logo, listMenu } = props;
    const [isOpen, setIsOpen] = useState(false);
    return (
        <>
        <div className="navbar sticky z-10 top-0 bg-white/85 drop-shadow-xl px-10 shadow-lg">
        <div className="navbar-start">
            <div className="flex gap-4 justify-center items-center">
                <img src={logo} className="w-10" alt="" />
                <h1 className="font-bold italic whitespace-nowrap lg:whitespace-normal"><span className="text-red-600">Masedo</span> RentCar</h1>
            </div>
        </div>
        <div className="navbar-center hidden lg:flex">
            <ul className="menu menu-horizontal px-1">
                {listMenu.map((menu, index) => (
                    <li key={index}><a>{menu}</a></li>
                ))}
            </ul>
        </div>
        <div className="navbar-end">
            <a className="btn hidden lg:flex lg:text-center italic">Booking Sekarang!</a>
            <div className="lg:hidden">
                <FontAwesomeIcon className='bg-white/90 p-3 rounded-xl' onClick={() =>setIsOpen(!isOpen)} icon={faBars} />
                {isOpen ?
                    <ul className="menu fixed right-1 menu-sm dropdown-content bg-base-100 rounded-box z-[1] mt-3 w-52 p-2 shadow">
                    {listMenu.map((menu, index) => (
                        <li key={index}><a>{menu}</a></li>
                    ))}
                    </ul> :
                    null
                }
            </div>
        </div>
        </div>
            
        </>
    )
}