import { LayoutContent } from "./Components/Layout"
import logo from "./assets/img/logmr.jpeg"
import axios from "axios"
import banner from "./assets/img/hero.jpg"
import { useEffect, useState } from "react"

const App = () => {
const listMenu = ['Home','List Mobil' , 'Services', 'Testimonial','Gallery', 'ContactUs'];
const [isLoading, setisLoading] = useState(true)
const [users,setUsers] = useState([])

const getUserList = () =>{
  axios.get('https://jsonplaceholder.typicode.com/users')
    .then((res)=>setUsers(res.data))
    .catch((error)=> console.log(error.response))
}
console.log(users)
useEffect(() => {
  getUserList();
  setTimeout(()=>{
    setisLoading(false)
  },2000)
},[])
  return (
    <>
    <LayoutContent listMenu={listMenu} logo={logo}>
    {/* HOME */}
    <section id="home"
      className="relative bg-[url(https://img.freepik.com/free-photo/luxurious-car-parked-highway-with-illuminated-headlight-sunset_181624-60607.jpg?t=st=1727523566~exp=1727527166~hmac=8ac58eb2f9f5809903b8c93aa1f670827a002a5e367ea83d0953b6dcba9bb04c&w=1060)] bg-cover bg-center bg-no-repeat"
    >
      <div
        className="absolute inset-0 bg-gray-900/75 sm:bg-transparent sm:from-gray-900/95 sm:to-gray-900/25 ltr:sm:bg-gradient-to-r rtl:sm:bg-gradient-to-l"
      ></div>

      <div
        className="relative mx-auto max-w-screen-xl px-4 py-32 sm:px-6 lg:flex lg:h-screen lg:items-center lg:px-8"
      >
        <div className="max-w-xl text-center ltr:sm:text-left rtl:sm:text-right">
          <h1 className="text-3xl font-extrabold text-white sm:text-5xl">
            Let us find your

            <strong className="block font-extrabold text-rose-500"> Forever Home. </strong>
          </h1>

          <p className="mt-4 max-w-lg text-white sm:text-xl/relaxed">
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nesciunt illo tenetur fuga ducimus
            numquam ea!
          </p>

          <div className="mt-8 flex flex-wrap gap-4 text-center">
            <a
              href="#"
              className="block w-full rounded bg-rose-600 px-12 py-3 text-sm font-medium text-white shadow hover:bg-rose-700 focus:outline-none focus:ring active:bg-rose-500 sm:w-auto"
            >
              Get Started
            </a>

            <a
              href="#"
              className="block w-full rounded bg-white px-12 py-3 text-sm font-medium text-rose-600 shadow hover:text-rose-700 focus:outline-none focus:ring active:text-rose-500 sm:w-auto"
            >
              Learn More
            </a>
          </div>
        </div>
      </div>
    </section>
    <section id="users" className="min-h-screen">
    {isLoading ?
    <div>Loading...</div> : 
    <div className="w-full flex  bg-white">
      {users.map((item) => (
          <div className="bg-green-200 p-4">
            {item.name}
            </div>
      )
      )}
    </div>
    }
    </section>
    </LayoutContent>
    </>
  )
}

export default App

// https://docs.google.com/forms/d/e/1FAIpQLSe7J8W-uDW8W9FW_yNwcPtojjPkH9T07Au2lWL8ZU8KJbufqA/viewform